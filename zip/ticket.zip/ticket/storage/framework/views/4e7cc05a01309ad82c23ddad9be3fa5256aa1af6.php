
<?php $__env->startSection('content'); ?>
  <div class="text-center">
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
  </div>
  <div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
    <h2><?php echo e($queue->name); ?></h2>
    <table class="table">
      <thead>
        <tr>
          <td><?php echo app('translator')->get('ID'); ?></td>
          <td><?php echo app('translator')->get('Cliente'); ?></td>
          <td><?php echo app('translator')->get('Action'); ?></td>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $queue->clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($client->identity); ?></td>
          <td><?php echo e($client->name); ?></td>
          <td>
          	<?php if($client->status == 1): ?>
          		<a href="#" onclick="event.preventDefault()" class="btn btn-secondary"><?php echo app('translator')->get('Atendido'); ?></a>
          	<?php else: ?>
          		<a href="<?php echo e(route('clients.update', $client->id)); ?>" class="btn btn-success"><?php echo app('translator')->get('Atender'); ?></a>
          	<?php endif; ?>
          	<a href="<?php echo e(route('clients.destroy', $client->id)); ?>" class="btn btn-danger"><?php echo app('translator')->get('Eliminar'); ?></a>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ticket\resources\views/queue.blade.php ENDPATH**/ ?>