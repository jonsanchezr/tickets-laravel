
<?php $__env->startSection('content'); ?>

<div class="container-fluid">
	<div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
		<?php if($errors): ?>
		    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		        <div class="alert alert-danger" role="alert">
		            <?php echo e($error); ?>

		        </div>
		    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endif; ?>

		<?php if(session('success')): ?>
		    <div class="alert alert-success">
		        <?php echo e(session('success')); ?>

		    </div>
		<?php endif; ?>
	  
	  <form action="<?php echo e(route('tickets.store')); ?>" method="POST">
	    <?php echo csrf_field(); ?>
	    <div class="form-row">
		    <div class="form-group col-md-4">
		      <label for="identity"><?php echo app('translator')->get('Identidad'); ?></label>
		      <input type="text" class="form-control" name="identity" id="identity" placeholder="<?php echo app('translator')->get('Identidad'); ?>" required>
		    </div>

		    <div class="form-group col-md-4">
		      <label for="name"><?php echo app('translator')->get('Nombre'); ?></label>
		      <input type="text" class="form-control" name="name" id="name" placeholder="<?php echo app('translator')->get('Nombre'); ?>" required>
		    </div>

		    <div class="form-group col-md-2">
		      <label for="queue"><?php echo app('translator')->get('Cola'); ?></label>
		      <select id="queue" class="form-control" name="queue_id" required>
		        <option selected value=""><?php echo app('translator')->get('Seleccione una cola'); ?>...</option>
		        <?php $__currentLoopData = $queues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $queue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		            <option value="<?php echo e($queue->id); ?>"
		              ><?php echo e($queue->name); ?></option>     
		        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		      </select>
		    </div>

		    <div class="form-group col-md-2">
		      <label>Accion</label>
		      <button type="submit" class="form-control btn btn-primary"><?php echo app('translator')->get('Agregar'); ?></button>
		    </div>
		</div>   
	  </form>
	</div>

	<div class="row">
		<div class="col-md-6">
			<div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
			  <h2><?php echo app('translator')->get('Cola'); ?> 1</h2>
			  <table class="table">
			    <thead>
			      <tr>
			        <td><?php echo app('translator')->get('ID'); ?></td>
        			<td><?php echo app('translator')->get('Cliente'); ?></td>
			      </tr>
			    </thead>
			    <tbody>
			      <?php $__currentLoopData = $queue1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				      <?php if($client1->status == 0): ?>
					      <tr>
					        <td><?php echo e($client1->identity); ?></td>
					        <td><?php echo e($client1->name); ?></td>
					      </tr>
				      <?php endif; ?>
			      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			    </tbody>
			  </table>
			</div>
		</div>
		<div class="col-md-6">
			<div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
			  <h2><?php echo app('translator')->get('Cola'); ?> 2</h2>
			  <table class="table">
			    <thead>
			      <tr>
			        <td><?php echo app('translator')->get('ID'); ?></td>
        			<td><?php echo app('translator')->get('Cliente'); ?></td>
			      </tr>
			    </thead>
			    <tbody>
			      <?php $__currentLoopData = $queue2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			      	<?php if($client2->status == 0): ?>
				      <tr>
				        <td><?php echo e($client2->identity); ?></td>
				        <td><?php echo e($client2->name); ?></td>
				      </tr>
				    <?php endif; ?>
			      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			    </tbody>
			  </table>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ticket\resources\views/index.blade.php ENDPATH**/ ?>